from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient

from app.config import Settings
from app.domain import Candle, Quality
from app.features import aggregate_15m, feature_snapshot
from app.ingestion.providers import CoinbaseAdapter, DemoAdapter, MarketDataAdapter
from app.main import app, service
from app.model_registry import ModelRun, eligible_for_promotion
from app.models import RandomWalkQuantileModel
from app.services import ForecastService
from app.storage import MemoryRepository


def candles(n=60):
    start = datetime(2026, 1, 1, tzinfo=UTC)
    return [
        Candle(
            ts=start + timedelta(minutes=i),
            open=1 + i * 0.001,
            high=1.1 + i * 0.001,
            low=0.9 + i * 0.001,
            close=1 + i * 0.001,
            volume=1,
        )
        for i in range(n)
    ]


def test_utc_and_aggregation_alignment():
    rows = aggregate_15m(candles(31))
    assert len(rows) == 3 and all(c.ts.minute % 15 == 0 and c.ts.tzinfo == UTC for c in rows)


def test_features_exclude_prediction_timestamp():
    rows = candles()
    future = rows[-1]
    snap = feature_snapshot(rows, future.ts)
    assert snap["return_1"] != future.close / rows[-2].close - 1


def test_quantiles_are_ordered():
    result = RandomWalkQuantileModel().forecast(
        candles(), Settings(), Quality(status="ok", data_freshness_seconds=1)
    )
    assert all(x.p05 <= x.p25 <= x.p50 <= x.p75 <= x.p95 for x in result.forecasts)


def test_default_horizons_are_short_term_quarter_hour_steps():
    assert Settings().horizons == [15, 30, 45, 60]


def test_forecast_targets_are_aligned_to_quarter_hours():
    result = RandomWalkQuantileModel().forecast(
        candles(), Settings(), Quality(status="ok", data_freshness_seconds=1)
    )
    assert [point.target_interval_start.minute for point in result.forecasts] == [0, 15, 30, 45]


def test_api_has_disclaimer_and_status():
    service.adapter = DemoAdapter()
    with TestClient(app) as client:
        r = client.get("/v1/forecast/latest")
        assert r.status_code == 200
        assert r.json()["disclaimer"] and r.json()["status"] in {"ok", "degraded", "unavailable"}


def test_stale_data_is_degraded():
    class Stale(MarketDataAdapter):
        def fetch_candles(self, symbol, interval_seconds, limit):
            return [x.model_copy(update={"ts": x.ts - timedelta(days=1)}) for x in candles()]

    assert (
        ForecastService(MemoryRepository(), Stale(), Settings(max_data_age_seconds=1))
        .refresh()
        .status
        == "degraded"
    )


def test_promotion_requires_loss_and_calibration_improvement():
    base = ModelRun("a", "d", "f", {}, 0.1, 0.1)
    candidate = ModelRun("b", "d", "f", {}, 0.097, 0.08)
    assert eligible_for_promotion(candidate, base)[0]


def test_coinbase_normalizes_newest_first_payload(monkeypatch):
    class Response:
        def read(self):
            return b'[[1735689660,0.49,0.51,0.5,0.505,100],[1735689600,0.48,0.5,0.49,0.5,99]]'

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return None

    monkeypatch.setattr("app.ingestion.providers.urlopen", lambda *args, **kwargs: Response())
    rows = CoinbaseAdapter().fetch_candles("XRP/USD", 60, 2)
    assert [row.close for row in rows] == [0.5, 0.505]
    assert all(row.ts.tzinfo == UTC and row.provider == "coinbase" for row in rows)
