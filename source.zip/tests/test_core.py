from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient

from app.config import Settings
from app.domain import Candle, Quality
from app.features import aggregate_15m, feature_snapshot, market_regime_snapshot
from app.ingestion.providers import CoinbaseAdapter, DemoAdapter, MarketDataAdapter
from app.main import app, service
from app.model_registry import ModelRun, eligible_for_promotion
from app.model_monitor import evaluate_live_performance
from app.point_candidate import FEATURE_COLUMNS, feature_frame
from app.models import RandomWalkQuantileModel, select_directional_rule
from app.services import ForecastService
from app.storage import MemoryRepository


def candles(n=60):
    start = datetime(2026, 1, 1, tzinfo=UTC)
    return [
        Candle(
            ts=start + timedelta(minutes=i),
            open=1 + i * 0.001,
            high=1.1 + i * 0.001,
            low=0.9 + i * 0.001,
            close=1 + i * 0.001,
            volume=1,
        )
        for i in range(n)
    ]


def test_utc_and_aggregation_alignment():
    rows = aggregate_15m(candles(31))
    assert len(rows) == 3 and all(c.ts.minute % 15 == 0 and c.ts.tzinfo == UTC for c in rows)


def test_features_exclude_prediction_timestamp():
    rows = candles()
    future = rows[-1]
    snap = feature_snapshot(rows, future.ts)
    assert snap["return_1"] != future.close / rows[-2].close - 1


def test_quantiles_are_ordered():
    result = RandomWalkQuantileModel().forecast(
        candles(), Settings(), Quality(status="ok", data_freshness_seconds=1)
    )
    assert all(x.p05 <= x.p25 <= x.p50 <= x.p75 <= x.p95 for x in result.forecasts)


def test_directional_rule_abstains_without_minimum_evidence():
    result = select_directional_rule(candles(20), Settings(min_training_bars=30))
    assert result["call"] is False and result["samples"] < 30


def test_forecast_exposes_walk_forward_evidence():
    result = RandomWalkQuantileModel().forecast(
        candles(80), Settings(), Quality(status="ok", data_freshness_seconds=1)
    )
    assert result.signal in {"up", "down", "no_edge"}
    assert {"rule", "samples", "accuracy", "baseline", "call"} <= result.evidence.keys()


def test_default_horizons_are_short_term_quarter_hour_steps():
    assert Settings().horizons == [15, 30, 45, 60]


def test_forecast_targets_are_aligned_to_quarter_hours():
    result = RandomWalkQuantileModel().forecast(
        candles(), Settings(), Quality(status="ok", data_freshness_seconds=1)
    )
    assert [point.target_interval_start.minute for point in result.forecasts] == [0, 15, 30, 45]


def test_prediction_time_advances_elapsed_quarter_hour_target():
    rows = candles()
    as_of = rows[-1].ts.replace(minute=45, second=0)
    result = RandomWalkQuantileModel().forecast(
        rows, Settings(), Quality(status="ok", data_freshness_seconds=1), prediction_time=as_of
    )
    assert result.forecasts[0].target_interval_start == as_of + timedelta(minutes=15)


def test_prediction_time_controls_target_boundary_when_data_is_older():
    rows = candles()
    as_of = datetime(2026, 1, 1, 1, 1, tzinfo=UTC)
    result = RandomWalkQuantileModel().forecast(
        rows, Settings(), Quality(status="ok", data_freshness_seconds=1), prediction_time=as_of
    )
    assert result.forecasts[0].target_interval_start == datetime(2026, 1, 1, 1, 15, tzinfo=UTC)


def test_api_has_disclaimer_and_status():
    service.adapter = DemoAdapter()
    with TestClient(app) as client:
        r = client.get("/v1/forecast/latest")
        assert r.status_code == 200
        assert r.json()["disclaimer"] and r.json()["status"] in {"ok", "degraded", "unavailable"}


def test_refresh_endpoint_generates_a_fresh_forecast():
    service.adapter = DemoAdapter()
    with TestClient(app) as client:
        r = client.post("/v1/forecast/refresh")
        assert r.status_code == 200
        assert [x["horizon_minutes"] for x in r.json()["forecasts"]] == [15, 30, 45, 60]


def test_stale_data_is_degraded():
    class Stale(MarketDataAdapter):
        def fetch_candles(self, symbol, interval_seconds, limit):
            return [x.model_copy(update={"ts": x.ts - timedelta(days=1)}) for x in candles()]

    assert (
        ForecastService(MemoryRepository(), Stale(), Settings(max_data_age_seconds=1))
        .refresh()
        .status
        == "degraded"
    )


def test_freshness_is_measured_from_candle_close_not_open():
    now = datetime.now(UTC)

    class RecentlyClosed(MarketDataAdapter):
        def fetch_candles(self, symbol, interval_seconds, limit):
            row = Candle(
                ts=now - timedelta(minutes=16),
                symbol=symbol,
                interval_seconds=900,
                open=1,
                high=1.01,
                low=0.99,
                close=1,
                volume=10,
            )
            return [row]

    result = ForecastService(
        MemoryRepository(), RecentlyClosed(), Settings(max_data_age_seconds=120)
    ).refresh()
    assert result.status == "ok"
    assert result.quality.data_freshness_seconds < 120


def test_soft_staleness_keeps_forecast_with_degraded_label():
    now = datetime.now(UTC)

    class Delayed(MarketDataAdapter):
        def fetch_candles(self, symbol, interval_seconds, limit):
            return [
                Candle(
                    ts=now - timedelta(minutes=35),
                    symbol=symbol,
                    interval_seconds=900,
                    open=1,
                    high=1.01,
                    low=0.99,
                    close=1,
                    volume=10,
                )
            ]

    result = ForecastService(
        MemoryRepository(),
        Delayed(),
        Settings(max_data_age_seconds=300, hard_data_expiry_seconds=3600),
    ).refresh()
    assert result.status == "degraded"
    assert result.forecasts
    assert "delayed" in result.quality.reasons[0]


def test_hard_expiry_disables_forecast():
    now = datetime.now(UTC)

    class Expired(MarketDataAdapter):
        def fetch_candles(self, symbol, interval_seconds, limit):
            return [
                Candle(
                    ts=now - timedelta(hours=2),
                    symbol=symbol,
                    interval_seconds=900,
                    open=1,
                    high=1.01,
                    low=0.99,
                    close=1,
                    volume=10,
                )
            ]

    result = ForecastService(
        MemoryRepository(), Expired(), Settings(hard_data_expiry_seconds=3600)
    ).refresh()
    assert result.status == "degraded"
    assert not result.forecasts


def test_promotion_requires_loss_and_calibration_improvement():
    base = ModelRun("a", "d", "f", {}, 0.1, 0.1)
    candidate = ModelRun("b", "d", "f", {}, 0.097, 0.08)
    assert eligible_for_promotion(candidate, base)[0]


def test_coinbase_normalizes_newest_first_payload(monkeypatch):
    class Response:
        def read(self):
            return b'[[1735689660,0.49,0.51,0.5,0.505,100],[1735689600,0.48,0.5,0.49,0.5,99]]'

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return None

    monkeypatch.setattr("app.ingestion.providers.urlopen", lambda *args, **kwargs: Response())
    rows = CoinbaseAdapter().fetch_candles("XRP/USD", 60, 2)
    assert [row.close for row in rows] == [0.5, 0.505]
    assert all(row.ts.tzinfo == UTC and row.provider == "coinbase" for row in rows)


def test_coinbase_excludes_incomplete_candle(monkeypatch):
    current = int(datetime.now(UTC).replace(second=0, microsecond=0).timestamp())

    class Response:
        def read(self):
            return f'[[{current},0.49,0.51,0.5,0.505,100],[1735689600,0.48,0.5,0.49,0.5,99]]'.encode()

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return None

    monkeypatch.setattr("app.ingestion.providers.urlopen", lambda *args, **kwargs: Response())
    rows = CoinbaseAdapter().fetch_candles("XRP/USD", 900, 2)
    assert [row.close for row in rows] == [0.5]


def test_memory_repository_retention_is_bounded():
    repo = MemoryRepository(candle_retention=2, forecast_retention=2)
    repo.upsert_candles(candles(4))
    assert len(repo.get_candles("XRP/USD", 60, 10)) == 2


def test_service_passes_latest_timestamp_for_incremental_fetch():
    repo = MemoryRepository()
    existing = candles(2)
    repo.upsert_candles(existing)

    class Incremental(MarketDataAdapter):
        seen = None
        def fetch_candles(self, symbol, interval_seconds, limit, since=None):
            self.seen = since
            return [existing[-1].model_copy(update={"interval_seconds": 900})]

    adapter = Incremental()
    ForecastService(repo, adapter, Settings()).refresh()
    assert adapter.seen == existing[-1].ts


def test_live_monitor_measures_coverage_and_direction_accuracy():
    rows = candles(80)
    forecast = RandomWalkQuantileModel().forecast(
        rows[:60], Settings(), Quality(status="ok", data_freshness_seconds=1)
    )
    target = forecast.forecasts[0].target_interval_start
    actual = rows[60].model_copy(update={"ts": target, "close": forecast.reference_price * 1.001})
    snapshot = evaluate_live_performance([forecast], rows[:60] + [actual], minimum_samples=1)
    assert snapshot.resolved_samples == 1
    assert snapshot.coverage_90 is not None


def test_live_monitor_suppresses_persistently_bad_direction_calls():
    rows = candles(80)
    history = []
    actuals = list(rows)
    for i in range(3):
        forecast = RandomWalkQuantileModel().forecast(
            rows[:60], Settings(min_training_bars=1), Quality(status="ok", data_freshness_seconds=1)
        ).model_copy(update={"forecast_id": f"bad-{i}", "signal": "down"})
        target = forecast.forecasts[0].target_interval_start
        actuals.append(rows[60].model_copy(update={"ts": target, "close": forecast.reference_price * 1.01}))
        history.append(forecast)
    snapshot = evaluate_live_performance(history, actuals, minimum_samples=1)
    assert snapshot.suppress_direction is True


def test_market_regime_detects_volume_shock():
    rows = candles(10)
    rows[-1] = rows[-1].model_copy(update={"volume": 100})
    snapshot = market_regime_snapshot(rows)
    assert snapshot["regime_volume_ratio"] > 3
    assert snapshot["regime_liquidity_shock"] is True


def test_point_candidate_keeps_latest_live_row_separate_from_targets():
    rows = candles(80)
    frame = feature_frame(rows)
    training = frame.dropna(subset=FEATURE_COLUMNS + ["target_return"])
    live = frame.dropna(subset=FEATURE_COLUMNS)
    assert live.iloc[-1]["timestamp"] == rows[-1].ts
    assert training.iloc[-1]["timestamp"] == rows[-2].ts

