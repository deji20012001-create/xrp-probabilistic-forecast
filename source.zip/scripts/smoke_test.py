"""Post-deploy smoke test for Render or any compatible deployment."""

import json
import sys
from urllib.request import urlopen


base = (sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000").rstrip("/")
for path in ("/health", "/ready", "/v1/forecast/latest"):
    with urlopen(base + path, timeout=15) as response:
        if response.status != 200:
            raise SystemExit(f"{path} returned {response.status}")
        payload = json.loads(response.read())
        if path.endswith("latest") and not payload.get("forecasts"):
            raise SystemExit("latest forecast has no active forecast points")
print("smoke test passed")
