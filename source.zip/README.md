# XRP Forecast

Probabilistic XRP/USD 15-minute forecasting service. It reports distributions and uncertainty, never trading advice.

## Quick start

```bash
cp .env.example .env
docker compose up --build
```

Open `http://localhost:8000` for the dashboard and `http://localhost:8000/docs` for OpenAPI. For a local Python run:

```bash
python -m venv .venv && .venv/Scripts/activate
pip install -e '.[dev]'
uvicorn app.main:app --reload
pytest
```

## Design

`app/ingestion` owns provider adapters and canonicalization; `app/storage` is the repository boundary; `app/features` builds timestamp-safe features; `app/models` owns baselines, quantiles, registry and promotion; `app/backtesting` does walk-forward evaluation; `app/services` orchestrates inference and quality gating; `app/api` exposes versioned HTTP endpoints. PostgreSQL/TimescaleDB and Redis are configured for deployment; the MVP has an in-memory repository for zero-config local operation.

The default forecast is a conservative random-walk distribution whose dispersion is estimated from trailing realized volatility. It is a safe runnable baseline, **not a claim of predictive skill**. Enable/train configured quantile models only after walk-forward validation and calibration improve over it. The dashboard labels the model type and quality status.

## Data assumptions and limits

Provider adapters normalize timestamps to UTC and preserve raw payloads separately from canonical candles. No feature may use data at or after the prediction timestamp. The bundled `DemoAdapter` generates deterministic local candles only so the app works without credentials; it must not be used in production. Implement a credentialed exchange adapter in `app/ingestion/providers.py` and set it in configuration.

Cryptocurrency prices can gap, venues differ, historical behavior changes, and intervals can be badly calibrated during shocks. Forecasts are probabilistic estimates based on historical and available market data. Cryptocurrency markets are highly volatile. This tool does not provide financial, investment, trading, or legal advice, and it does not guarantee future prices or returns.

## Production notes

- Run migrations before app workers; retain raw events per your compliance policy and back up PostgreSQL with PITR plus off-site snapshots.
- Run ingestion and training as separate workers. Retraining cadence, providers, freshness, and promotion thresholds are environment-configured.
- Training-worker extras are installed with `pip install -e '.[training]'`; available families are quantile gradient boosting and ARIMA with empirical residual distributions. Register immutable run metadata and promote only through the validation gate.
- Alert on stale canonical candles, provider errors, missing intervals, failed jobs, p05/p95 coverage drift, and HTTP 5xx rates. Export `/metrics` to Prometheus and centralize JSON logs.
- Secure `POST /v1/backtests/run` with `ADMIN_API_KEY`; use a secret manager, TLS, network policies, and managed Redis/Postgres in production.
- `app.artifact_updater` provides deterministic closed-candle selection and atomic `history-data` updates for quarter-hour dashboard artifacts. It sorts candles, skips the forming interval, validates prices, de-duplicates timestamps, and preserves surrounding HTML.

## Deploy on Render

The included `render.yaml` provisions a Docker web service, Render Postgres, and a private Redis-compatible Key Value service. Push this repository to GitHub, then in Render choose **New > Blueprint**, select the repository, and apply the Blueprint. Render assigns an HTTPS `onrender.com` URL when the web service is healthy. Add a custom domain through the service settings when ready.

Before public launch, replace the in-memory repository with the Postgres/Redis implementations and run the schema migrations against the provisioned database. Render Postgres is standard PostgreSQL; use a managed TimescaleDB-compatible service if hypertables are a hard production requirement. Keep `ADMIN_API_KEY` only in Render's generated/secret environment variables.

## Example

```bash
curl http://localhost:8000/v1/forecast/latest
curl 'http://localhost:8000/v1/market/candles?limit=50'
```
