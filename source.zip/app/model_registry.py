"""Immutable run metadata and conservative promotion decision boundary."""

from dataclasses import dataclass


@dataclass(frozen=True)
class ModelRun:
    version: str
    dataset_version: str
    feature_version: str
    parameters: dict[str, object]
    pinball_loss: float
    coverage_error: float  # absolute difference from nominal coverage


def eligible_for_promotion(
    candidate: ModelRun, production: ModelRun, min_improvement: float = 0.02
) -> tuple[bool, str]:
    relative = (production.pinball_loss - candidate.pinball_loss) / max(
        production.pinball_loss, 1e-12
    )
    if relative < min_improvement:
        return False, "Candidate did not sufficiently improve walk-forward pinball loss."
    if candidate.coverage_error >= production.coverage_error:
        return False, "Candidate did not improve interval calibration."
    return True, "Candidate improves out-of-sample loss and calibration."
