"""Deterministic updater for quarter-hour XRP dashboard history artifacts."""

from __future__ import annotations

import json
import math
import os
import re
import statistics
import tempfile
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Iterable, Protocol


class CandleLike(Protocol):
    ts: datetime
    close: float
    interval_seconds: int


HISTORY_DATA = re.compile(
    r'(<script\b(?=[^>]*\bid=["\']history-data["\'])[^>]*>)(\s*)(\[.*?\])(\s*)(</script>)',
    re.IGNORECASE | re.DOTALL,
)


@dataclass(frozen=True)
class BoundaryPrice:
    timestamp: datetime
    price: float


def quarter_hour_boundary(now: datetime) -> datetime:
    """Floor an aware timestamp to its most recent UTC quarter hour."""
    if now.tzinfo is None:
        raise ValueError("now must be timezone-aware")
    now = now.astimezone(UTC)
    return now.replace(minute=(now.minute // 15) * 15, second=0, microsecond=0)


def select_closed_candle(candles: Iterable[CandleLike], now: datetime) -> BoundaryPrice:
    """Select the candle that closed at the current quarter-hour boundary."""
    rows = sorted(candles, key=lambda row: row.ts)
    if len(rows) < 2:
        raise ValueError("at least two candles are required")
    boundary = quarter_hour_boundary(now)
    expected_start = boundary - timedelta(minutes=15)
    chosen = next((row for row in rows if row.ts.astimezone(UTC) == expected_start), None)
    if chosen is not None:
        return BoundaryPrice(boundary, float(chosen.close))
    fallback = rows[-2]
    return BoundaryPrice(fallback.ts.astimezone(UTC) + timedelta(seconds=fallback.interval_seconds), float(fallback.close))


def update_history_artifact(
    artifact: Path,
    point: BoundaryPrice,
    *,
    max_entries: int = 200,
    outlier_fraction: float = 0.25,
) -> str:
    """Update only history-data JSON and atomically replace the artifact."""
    if not math.isfinite(point.price) or point.price <= 0:
        raise ValueError("price must be finite and positive")
    if point.timestamp.tzinfo is None or point.timestamp.minute not in {0, 15, 30, 45}:
        raise ValueError("timestamp must be an aware quarter-hour boundary")

    source = artifact.read_text(encoding="utf-8")
    match = HISTORY_DATA.search(source)
    if not match:
        raise ValueError("history-data element is missing")
    history = json.loads(match.group(3))
    if not isinstance(history, list):
        raise ValueError("history-data must contain a JSON array")

    recent = [float(entry["p"]) for entry in history[-20:] if isinstance(entry, dict) and isinstance(entry.get("p"), (int, float))]
    if recent:
        median = statistics.median(recent)
        if median > 0 and abs(point.price - median) / median > outlier_fraction:
            raise ValueError("price is outside the recent-history validation range")

    timestamp = point.timestamp.astimezone(UTC).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    entry = {"t": timestamp, "p": point.price}
    status = "updated"
    if history and history[-1].get("t") == timestamp:
        history[-1] = entry
        status = "replaced"
    else:
        history.append(entry)
    payload = json.dumps(history[-max_entries:], separators=(",", ":"))
    updated = source[: match.start(3)] + payload + source[match.end(3) :]

    descriptor, temporary = tempfile.mkstemp(prefix=artifact.name + ".", suffix=".tmp", dir=artifact.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="") as handle:
            handle.write(updated)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, artifact)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return status
