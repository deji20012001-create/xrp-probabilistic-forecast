"""Walk-forward utilities; intentionally no random shuffle."""

from dataclasses import dataclass

import numpy as np


@dataclass
class BacktestResult:
    mae: float
    rmse: float
    pinball_loss: float
    coverage_90: float


def pinball(y: np.ndarray, q: np.ndarray, alpha: float) -> float:
    error = y - q
    return float(np.mean(np.maximum(alpha * error, (alpha - 1) * error)))


def evaluate(
    actual: np.ndarray, median: np.ndarray, p05: np.ndarray, p95: np.ndarray
) -> BacktestResult:
    return BacktestResult(
        mae=float(np.mean(abs(actual - median))),
        rmse=float(np.sqrt(np.mean((actual - median) ** 2))),
        pinball_loss=(
            pinball(actual, p05, 0.05) + pinball(actual, median, 0.5) + pinball(actual, p95, 0.95)
        )
        / 3,
        coverage_90=float(np.mean((actual >= p05) & (actual <= p95))),
    )


def eligible_origins(length: int, min_train: int, horizon: int) -> list[int]:
    return list(range(min_train, length - horizon))
