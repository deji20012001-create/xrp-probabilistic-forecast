"""Optional training families, kept off the real-time path until promotion.

Install extras (`scikit-learn`, `statsmodels`) in the training worker image.  These
classes deliberately expose quantile/distribution interfaces rather than point-only APIs.
"""

from typing import Protocol

import numpy as np


class DistributionTrainer(Protocol):
    def fit(self, x: np.ndarray, y: np.ndarray) -> None: ...
    def predict_quantiles(self, x: np.ndarray) -> dict[float, np.ndarray]: ...


class GradientBoostedQuantiles:
    """Tree quantile regressors; configure separately per percentile."""

    def __init__(self, quantiles: tuple[float, ...] = (0.05, 0.25, 0.5, 0.75, 0.95)) -> None:
        self.quantiles = quantiles
        self.models: dict[float, object] = {}

    def fit(self, x: np.ndarray, y: np.ndarray) -> None:
        from sklearn.ensemble import GradientBoostingRegressor

        self.models = {
            q: GradientBoostingRegressor(loss="quantile", alpha=q, random_state=7).fit(x, y)
            for q in self.quantiles
        }

    def predict_quantiles(self, x: np.ndarray) -> dict[float, np.ndarray]:
        return {q: model.predict(x) for q, model in self.models.items()}


class ARIMAResidualDistribution:
    """ARIMA mean with empirical residual quantiles for its predictive distribution."""

    def __init__(self, order: tuple[int, int, int] = (2, 0, 2)) -> None:
        self.order, self.result, self.residuals = order, None, np.array([])

    def fit(self, _: np.ndarray, y: np.ndarray) -> None:
        from statsmodels.tsa.arima.model import ARIMA

        self.result = ARIMA(y, order=self.order).fit()
        self.residuals = np.asarray(self.result.resid)

    def predict_quantiles(self, x: np.ndarray) -> dict[float, np.ndarray]:
        if self.result is None:
            raise RuntimeError("fit before predict")
        mean = np.asarray(self.result.forecast(steps=len(x)))
        return {q: mean + np.quantile(self.residuals, q) for q in (0.05, 0.25, 0.5, 0.75, 0.95)}
