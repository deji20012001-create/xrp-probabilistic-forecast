from datetime import UTC, datetime, timedelta
from itertools import pairwise
from uuid import uuid4

from app.config import Settings
from app.domain import ForecastResponse, Quality
from app.features import candle_close_time
from app.ingestion.providers import MarketDataAdapter
from app.models import RandomWalkQuantileModel
from app.storage import MemoryRepository


class ForecastService:
    def __init__(self, repo: MemoryRepository, adapter: MarketDataAdapter, cfg: Settings, fallback_adapter: MarketDataAdapter | None = None) -> None:
        self.repo, self.adapter, self.cfg = repo, adapter, cfg
        self.fallback_adapter = fallback_adapter
        self.model = RandomWalkQuantileModel()
        self.provider_failures = 0
        self.circuit_open_until: datetime | None = None

    def _fetch(self, since: datetime | None) -> tuple[list, Exception | None]:
        if self.circuit_open_until and datetime.now(UTC) < self.circuit_open_until:
            primary_error = RuntimeError("primary provider circuit breaker is cooling down")
            if self.fallback_adapter is not None:
                try:
                    rows = self.fallback_adapter.fetch_candles(self.cfg.symbol, 900, 300, since=since)
                    if rows:
                        return rows, RuntimeError("primary provider circuit open; fallback active")
                except (OSError, RuntimeError):
                    pass
            return [], primary_error
        try:
            try:
                rows = self.adapter.fetch_candles(self.cfg.symbol, 900, 300, since=since)
            except TypeError:  # compatibility with simple custom/test adapters
                rows = self.adapter.fetch_candles(self.cfg.symbol, 900, 300)
            if not rows:
                raise RuntimeError("provider returned no candles")
            self.provider_failures = 0
            self.circuit_open_until = None
            return rows, None
        except (OSError, RuntimeError) as primary_error:
            self.provider_failures += 1
            if self.provider_failures >= self.cfg.provider_circuit_failures:
                self.circuit_open_until = datetime.now(UTC) + timedelta(seconds=self.cfg.provider_circuit_cooldown_seconds)
            if self.fallback_adapter is not None:
                try:
                    rows = self.fallback_adapter.fetch_candles(self.cfg.symbol, 900, 300, since=since)
                    if rows:
                        return rows, RuntimeError(f"primary provider unavailable; fallback active ({type(primary_error).__name__})")
                except (OSError, RuntimeError):
                    pass
            return [], primary_error

    def refresh(self) -> ForecastResponse:
        cached_rows = self.repo.get_candles(self.cfg.symbol, 900, 300)
        since = cached_rows[-1].ts if cached_rows else None
        rows, provider_error = self._fetch(since)
        if not rows:
            exc = provider_error or RuntimeError("provider returned no candles")
            cached = self.repo.get_candles(self.cfg.symbol, 900, 1)
            if not cached:
                previous = self.repo.history(1)
                if previous and previous[-1].forecasts:
                    prior = previous[-1]
                    age = max((datetime.now(UTC) - prior.generated_at).total_seconds(), 0)
                    if age <= self.cfg.hard_data_expiry_seconds:
                        quality = Quality(
                            status="degraded",
                            data_freshness_seconds=age,
                            reasons=["market provider temporarily unavailable; showing last valid forecast"],
                        )
                        return prior.model_copy(update={"status": "degraded", "quality": quality})
                quality = Quality(
                    status="unavailable",
                    data_freshness_seconds=None,
                    reasons=[f"market provider unavailable: {type(exc).__name__}"],
                )
                return ForecastResponse(
                    forecast_id=str(uuid4()),
                    generated_at=datetime.now(UTC),
                    reference_price=None,
                    status="unavailable",
                    quality=quality,
                    model_version=self.model.version,
                    model_kind=self.model.kind,
                    uncertainty_explanation="No valid, current market data is available; forecast generation is disabled.",
                    forecasts=[],
                )
            rows = self.repo.get_candles(self.cfg.symbol, 900, 300)
        self.repo.upsert_candles(rows)
        rows = self.repo.get_candles(self.cfg.symbol, 900, 300)
        previous = self.repo.history(1)
        if (
            provider_error is None
            and cached_rows
            and rows[-1].ts == cached_rows[-1].ts
            and previous
            and previous[-1].forecasts
            and previous[-1].forecasts[0].target_interval_start > datetime.now(UTC)
        ):
            return previous[-1]
        # Candle timestamps identify interval starts. Freshness must be measured
        # from the candle's close, otherwise every completed 15-minute bar looks
        # 15 minutes older than it really is and is incorrectly disabled shortly
        # after publication.
        latest_close_time = candle_close_time(rows[-1])
        age = (datetime.now(UTC) - latest_close_time).total_seconds()
        reasons: list[str] = []
        hard_failure = False
        if provider_error is not None:
            reasons.append(str(provider_error) if "fallback active" in str(provider_error) else "market provider temporarily unavailable; using cached completed candles")
        if age > self.cfg.max_data_age_seconds:
            reasons.append(f"latest completed candle delayed by {max(round(age / 60), 1)} minutes")
        if age > self.cfg.hard_data_expiry_seconds:
            hard_failure = True
            reasons.append("market data exceeded the hard expiry limit")
        gaps = sum((b.ts - a.ts).total_seconds() > 930 for a, b in pairwise(rows))
        if gaps:
            reasons.append(f"{gaps} missing or delayed 15-minute candle intervals")
        if len(rows) > 1 and abs(rows[-1].close / rows[-2].close - 1) > 0.20:
            reasons.append("anomalous single-candle price move")
            hard_failure = True
        quality = Quality(
            status="ok" if not reasons else "degraded",
            data_freshness_seconds=max(age, 0),
            reasons=reasons,
        )
        now = datetime.now(UTC)
        result = self.model.forecast(rows, self.cfg, quality, prediction_time=now)
        if hard_failure:
            result = result.model_copy(
                update={
                    "forecasts": [],
                    "uncertainty_explanation": (
                        "Forecast generation is disabled because market data exceeded "
                        "the hard safety limit or failed integrity checks."
                    ),
                }
            )
        self.repo.save_forecast(result)
        return result
