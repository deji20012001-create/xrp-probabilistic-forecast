from datetime import UTC, datetime
from itertools import pairwise
from uuid import uuid4

from app.config import Settings
from app.domain import ForecastResponse, Quality
from app.ingestion.providers import MarketDataAdapter
from app.models import RandomWalkQuantileModel
from app.storage import MemoryRepository


class ForecastService:
    def __init__(self, repo: MemoryRepository, adapter: MarketDataAdapter, cfg: Settings) -> None:
        self.repo, self.adapter, self.cfg = repo, adapter, cfg
        self.model = RandomWalkQuantileModel()

    def refresh(self) -> ForecastResponse:
        try:
            rows = self.adapter.fetch_candles(self.cfg.symbol, 60, 240)
            if not rows:
                raise RuntimeError("provider returned no candles")
        except (OSError, RuntimeError) as exc:
            cached = self.repo.get_candles(self.cfg.symbol, 60, 1)
            if not cached:
                quality = Quality(
                    status="unavailable",
                    data_freshness_seconds=None,
                    reasons=[f"market provider unavailable: {type(exc).__name__}"],
                )
                return ForecastResponse(
                    forecast_id=str(uuid4()),
                    generated_at=datetime.now(UTC),
                    reference_price=None,
                    status="unavailable",
                    quality=quality,
                    model_version=self.model.version,
                    model_kind=self.model.kind,
                    uncertainty_explanation="No valid, current market data is available; forecast generation is disabled.",
                    forecasts=[],
                )
            rows = self.repo.get_candles(self.cfg.symbol, 60, 240)
        self.repo.upsert_candles(rows)
        age = (datetime.now(UTC) - rows[-1].ts).total_seconds()
        reasons: list[str] = []
        if age > self.cfg.max_data_age_seconds:
            reasons.append("canonical market data is stale")
        gaps = sum((b.ts - a.ts).total_seconds() > 90 for a, b in pairwise(rows))
        if gaps:
            reasons.append(f"{gaps} missing or delayed one-minute candle intervals")
        if len(rows) > 1 and abs(rows[-1].close / rows[-2].close - 1) > 0.20:
            reasons.append("anomalous single-candle price move")
        quality = Quality(
            status="ok" if not reasons else "degraded",
            data_freshness_seconds=max(age, 0),
            reasons=reasons,
        )
        result = self.model.forecast(rows, self.cfg, quality)
        self.repo.save_forecast(result)
        return result
