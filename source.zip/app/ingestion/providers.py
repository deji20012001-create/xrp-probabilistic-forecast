"""Swappable market-data adapters with normalization at the boundary."""

import json
import math
from abc import ABC, abstractmethod
from datetime import UTC, datetime, timedelta
from time import sleep
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from app.domain import Candle


class MarketDataAdapter(ABC):
    @abstractmethod
    def fetch_candles(self, symbol: str, interval_seconds: int, limit: int, since: datetime | None = None) -> list[Candle]: ...


class ProviderError(RuntimeError):
    """Provider failure safe to surface as a degraded or unavailable data state."""


class CoinbaseAdapter(MarketDataAdapter):
    """Public Coinbase Exchange candles; API keys are not used for market data."""

    base_url = "https://api.exchange.coinbase.com"

    def __init__(self, timeout_seconds: float = 10, max_retries: int = 3) -> None:
        self.timeout_seconds = timeout_seconds
        self.max_retries = max_retries

    def fetch_candles(self, symbol: str, interval_seconds: int, limit: int, since: datetime | None = None) -> list[Candle]:
        if interval_seconds not in {60, 300, 900, 3600, 21600, 86400}:
            raise ProviderError("Coinbase does not support this candle interval")
        product = symbol.replace("/", "-")
        params: dict[str, object] = {"granularity": interval_seconds}
        if since is not None:
            params["start"] = since.astimezone(UTC).isoformat().replace("+00:00", "Z")
        query = urlencode(params)
        url = f"{self.base_url}/products/{product}/candles?{query}"
        headers = {"Accept": "application/json", "User-Agent": "xrp-probabilistic-forecast/0.1"}
        payload: object | None = None
        for attempt in range(self.max_retries):
            try:
                request = Request(url, headers=headers)
                with urlopen(request, timeout=self.timeout_seconds) as response:
                    payload = json.loads(response.read().decode("utf-8"))
                break
            except (HTTPError, URLError, TimeoutError, json.JSONDecodeError) as exc:
                if attempt == self.max_retries - 1:
                    raise ProviderError(f"Coinbase request failed: {type(exc).__name__}") from exc
                sleep(2**attempt)
        if not isinstance(payload, list):
            raise ProviderError("Coinbase returned an invalid candle payload")
        rows: list[Candle] = []
        now = datetime.now(UTC)
        for item in payload[: min(limit, 300)]:
            if not isinstance(item, list) or len(item) < 6:
                continue
            try:
                ts = datetime.fromtimestamp(float(item[0]), UTC)
                # Exchange candle endpoints can still be changing. Only admit bars
                # whose full interval ended before this fetch.
                if ts + timedelta(seconds=interval_seconds) > now:
                    continue
                low, high, opening, close, volume = map(float, item[1:6])
                if min(low, high, opening, close) <= 0 or volume < 0 or low > high:
                    continue
                rows.append(Candle(symbol=symbol, interval_seconds=interval_seconds, ts=ts, open=opening, high=high, low=low, close=close, volume=volume, provider="coinbase"))
            except (TypeError, ValueError, OverflowError):
                continue
        if not rows:
            raise ProviderError("Coinbase returned no valid candles")
        rows = sorted(rows, key=lambda row: row.ts)
        return [row for row in rows if since is None or row.ts >= since][-limit:]


class KrakenAdapter(MarketDataAdapter):
    """Fallback public Kraken OHLC feed."""

    base_url = "https://api.kraken.com/0/public/OHLC"

    def __init__(self, timeout_seconds: float = 10) -> None:
        self.timeout_seconds = timeout_seconds

    def fetch_candles(self, symbol: str, interval_seconds: int, limit: int, since: datetime | None = None) -> list[Candle]:
        if interval_seconds % 60:
            raise ProviderError("Kraken interval must be whole minutes")
        params: dict[str, object] = {"pair": symbol.replace("/", ""), "interval": interval_seconds // 60}
        if since is not None:
            params["since"] = int(since.timestamp())
        request = Request(f"{self.base_url}?{urlencode(params)}", headers={"User-Agent": "xrp-probabilistic-forecast/0.2"})
        try:
            with urlopen(request, timeout=self.timeout_seconds) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except (HTTPError, URLError, TimeoutError, json.JSONDecodeError) as exc:
            raise ProviderError(f"Kraken request failed: {type(exc).__name__}") from exc
        result = payload.get("result", {}) if isinstance(payload, dict) else {}
        series = next((v for k, v in result.items() if k != "last" and isinstance(v, list)), [])
        now = datetime.now(UTC)
        rows = []
        for item in series:
            try:
                ts = datetime.fromtimestamp(float(item[0]), UTC)
                if ts + timedelta(seconds=interval_seconds) > now:
                    continue
                opening, high, low, close = map(float, item[1:5])
                volume = float(item[6])
                rows.append(Candle(symbol=symbol, interval_seconds=interval_seconds, ts=ts, open=opening, high=high, low=low, close=close, volume=volume, provider="kraken"))
            except (TypeError, ValueError, IndexError):
                continue
        if not rows:
            raise ProviderError("Kraken returned no valid completed candles")
        return sorted(rows, key=lambda row: row.ts)[-limit:]


class DemoAdapter(MarketDataAdapter):
    """Deterministic development source; never use as live market data."""

    def fetch_candles(self, symbol: str, interval_seconds: int, limit: int, since: datetime | None = None) -> list[Candle]:
        now = datetime.now(UTC).replace(second=0, microsecond=0)
        start = now - timedelta(seconds=interval_seconds * limit)
        out: list[Candle] = []
        price = 0.52
        for i in range(limit):
            ts = start + timedelta(seconds=i * interval_seconds)
            change = 0.0008 * math.sin(i / 8) + 0.0004 * math.cos(i / 3)
            close = price * (1 + change)
            out.append(
                Candle(
                    ts=ts,
                    symbol=symbol,
                    interval_seconds=interval_seconds,
                    open=price,
                    high=max(price, close) * 1.001,
                    low=min(price, close) * 0.999,
                    close=close,
                    volume=10000 + i,
                    provider="demo",
                )
            )
            price = close
        return out
