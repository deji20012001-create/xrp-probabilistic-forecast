"""Backend-only forecast calibration and live-performance safeguards."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from math import sqrt

from app.domain import Candle, ForecastResponse


@dataclass(frozen=True)
class MonitorSnapshot:
    resolved_samples: int = 0
    directional_samples: int = 0
    directional_accuracy: float | None = None
    coverage_50: float | None = None
    coverage_90: float | None = None
    interval_scale: float = 1.0
    suppress_direction: bool = False

    def evidence(self) -> dict[str, float | int | bool]:
        out: dict[str, float | int | bool] = {
            "monitor_resolved_samples": self.resolved_samples,
            "monitor_directional_samples": self.directional_samples,
            "monitor_interval_scale": round(self.interval_scale, 4),
            "monitor_suppressed_direction": self.suppress_direction,
        }
        if self.directional_accuracy is not None:
            out["monitor_directional_accuracy"] = round(self.directional_accuracy, 4)
        if self.coverage_50 is not None:
            out["monitor_coverage_50"] = round(self.coverage_50, 4)
        if self.coverage_90 is not None:
            out["monitor_coverage_90"] = round(self.coverage_90, 4)
        return out


def _actual_at(candles: list[Candle], target: datetime) -> float | None:
    # A target names a candle interval start. Its close is known only after that
    # interval completes, so match the completed candle with the same timestamp.
    for candle in candles:
        if candle.ts == target:
            return candle.close
    return None


def evaluate_live_performance(
    history: list[ForecastResponse],
    candles: list[Candle],
    *,
    minimum_samples: int = 30,
    minimum_direction_accuracy: float = 0.52,
) -> MonitorSnapshot:
    """Resolve past 15-minute forecasts without leaking future observations."""
    resolved: list[tuple[ForecastResponse, object, float]] = []
    seen: set[str] = set()
    for forecast in history:
        if forecast.forecast_id in seen or not forecast.forecasts or forecast.reference_price is None:
            continue
        seen.add(forecast.forecast_id)
        point = next((p for p in forecast.forecasts if p.horizon_minutes == 15), None)
        if point is None:
            continue
        actual = _actual_at(candles, point.target_interval_start)
        if actual is not None:
            resolved.append((forecast, point, actual))

    if not resolved:
        return MonitorSnapshot()

    coverage_50 = sum(p.p25 <= actual <= p.p75 for _, p, actual in resolved) / len(resolved)
    coverage_90 = sum(p.p05 <= actual <= p.p95 for _, p, actual in resolved) / len(resolved)
    directional = [
        (forecast.signal == ("up" if actual > forecast.reference_price else "down"))
        for forecast, _, actual in resolved
        if forecast.signal in {"up", "down"} and actual != forecast.reference_price
    ]
    accuracy = sum(directional) / len(directional) if directional else None

    # Expand intervals when realized coverage is low and contract them when it
    # is persistently excessive. Keep the adjustment conservative and bounded.
    scale = 1.0
    if len(resolved) >= 20:
        observed = max(coverage_90, 0.05)
        scale = min(max(sqrt(0.90 / observed), 0.85), 1.35)
    suppress = (
        len(directional) >= minimum_samples
        and accuracy is not None
        and accuracy < minimum_direction_accuracy
    )
    return MonitorSnapshot(
        resolved_samples=len(resolved),
        directional_samples=len(directional),
        directional_accuracy=accuracy,
        coverage_50=coverage_50,
        coverage_90=coverage_90,
        interval_scale=scale,
        suppress_direction=suppress,
    )

