from app.domain import Candle, ForecastResponse


class MemoryRepository:
    def __init__(self) -> None:
        self.candles: dict[tuple[str, int], list[Candle]] = {}
        self.forecasts: list[ForecastResponse] = []
        self.raw_events: list[dict[str, object]] = []

    def record_raw_event(self, provider: str, payload: object) -> None:
        self.raw_events.append({"provider": provider, "payload": payload})

    def upsert_candles(self, rows: list[Candle]) -> None:
        for row in rows:
            key = (row.symbol, row.interval_seconds)
            existing = {x.ts: x for x in self.candles.get(key, [])}
            existing[row.ts] = row
            self.candles[key] = sorted(existing.values(), key=lambda x: x.ts)

    def get_candles(self, symbol: str, interval_seconds: int, limit: int) -> list[Candle]:
        return self.candles.get((symbol, interval_seconds), [])[-limit:]

    def save_forecast(self, forecast: ForecastResponse) -> None:
        self.forecasts.append(forecast)

    def history(self, limit: int) -> list[ForecastResponse]:
        return self.forecasts[-limit:]
