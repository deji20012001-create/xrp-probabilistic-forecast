import logging

from app.domain import Candle, ForecastResponse

logger = logging.getLogger(__name__)


class MemoryRepository:
    def __init__(self, candle_retention: int = 1000, forecast_retention: int = 200) -> None:
        self.candles: dict[tuple[str, int], list[Candle]] = {}
        self.forecasts: list[ForecastResponse] = []
        self.raw_events: list[dict[str, object]] = []
        self.candle_retention = candle_retention
        self.forecast_retention = forecast_retention

    def record_raw_event(self, provider: str, payload: object) -> None:
        self.raw_events.append({"provider": provider, "payload": payload})
        self.raw_events = self.raw_events[-self.candle_retention:]

    def upsert_candles(self, rows: list[Candle]) -> None:
        for row in rows:
            key = (row.symbol, row.interval_seconds)
            existing = {x.ts: x for x in self.candles.get(key, [])}
            existing[row.ts] = row
            self.candles[key] = sorted(existing.values(), key=lambda x: x.ts)[-self.candle_retention:]

    def get_candles(self, symbol: str, interval_seconds: int, limit: int) -> list[Candle]:
        return self.candles.get((symbol, interval_seconds), [])[-limit:]

    def save_forecast(self, forecast: ForecastResponse) -> None:
        if self.forecasts and self.forecasts[-1].forecast_id == forecast.forecast_id:
            self.forecasts[-1] = forecast
        else:
            self.forecasts.append(forecast)
        self.forecasts = self.forecasts[-self.forecast_retention:]

    def history(self, limit: int) -> list[ForecastResponse]:
        return self.forecasts[-limit:]


class RedisRepository(MemoryRepository):
    """Redis-backed state with an in-process fallback if the cache is interrupted."""

    def __init__(self, url: str, candle_retention: int = 1000, forecast_retention: int = 200) -> None:
        super().__init__(candle_retention, forecast_retention)
        import redis
        self.client = redis.from_url(url, decode_responses=True, socket_timeout=2, socket_connect_timeout=2)
        self.client.ping()

    def _key(self, symbol: str, interval: int) -> str:
        return f"xrp:candles:{symbol}:{interval}"

    def upsert_candles(self, rows: list[Candle]) -> None:
        super().upsert_candles(rows)
        for row in rows:
            try:
                key = self._key(row.symbol, row.interval_seconds)
                self.client.zadd(key, {row.model_dump_json(): row.ts.timestamp()})
                self.client.zremrangebyrank(key, 0, -(self.candle_retention + 1))
            except Exception as exc:
                logger.warning("redis candle write failed: %s", type(exc).__name__)

    def get_candles(self, symbol: str, interval_seconds: int, limit: int) -> list[Candle]:
        try:
            values = self.client.zrange(self._key(symbol, interval_seconds), -limit, -1)
            if values:
                rows = [Candle.model_validate_json(value) for value in values]
                super().upsert_candles(rows)
                return rows
        except Exception as exc:
            logger.warning("redis candle read failed: %s", type(exc).__name__)
        return super().get_candles(symbol, interval_seconds, limit)

    def save_forecast(self, forecast: ForecastResponse) -> None:
        super().save_forecast(forecast)
        try:
            payload = forecast.model_dump_json()
            pipe = self.client.pipeline()
            pipe.set("xrp:forecast:latest", payload)
            pipe.lpush("xrp:forecast:history", payload)
            pipe.ltrim("xrp:forecast:history", 0, self.forecast_retention - 1)
            pipe.execute()
        except Exception as exc:
            logger.warning("redis forecast write failed: %s", type(exc).__name__)

    def history(self, limit: int) -> list[ForecastResponse]:
        try:
            values = self.client.lrange("xrp:forecast:history", 0, limit - 1)
            if values:
                return list(reversed([ForecastResponse.model_validate_json(v) for v in values]))
        except Exception as exc:
            logger.warning("redis forecast read failed: %s", type(exc).__name__)
        return super().history(limit)


def configured_repository(redis_url: str, candle_retention: int = 1000, forecast_retention: int = 200) -> MemoryRepository:
    try:
        return RedisRepository(redis_url, candle_retention, forecast_retention)
    except Exception as exc:
        logger.warning("Redis unavailable at startup; using bounded memory cache: %s", type(exc).__name__)
        return MemoryRepository(candle_retention, forecast_retention)
