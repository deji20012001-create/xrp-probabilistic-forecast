from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    app_env: str = "development"
    symbol: str = "XRP/USD"
    forecast_horizons_minutes: str = "15,30,45,60"
    max_data_age_seconds: int = 1200
    hard_data_expiry_seconds: int = 3600
    provider_grace_seconds: int = 300
    admin_api_key: str = "change-me"
    model_name: str = "realized_volatility_random_walk"
    model_family: str = "baseline"
    database_url: str = "postgresql://xrp:xrp@localhost:5432/xrp_forecast"
    redis_url: str = "redis://localhost:6379/0"
    provider: str = "coinbase"
    alert_freshness_seconds: int = 1200
    min_training_bars: int = 30
    minimum_edge_over_baseline: float = 0.03
    neutral_volatility_fraction: float = 0.55
    forecast_refresh_delay_seconds: int = 20
    provider_circuit_failures: int = 3
    provider_circuit_cooldown_seconds: int = 180
    candle_retention: int = 1000
    forecast_retention: int = 200
    monitor_minimum_samples: int = 30
    monitor_minimum_direction_accuracy: float = 0.52
    enable_cross_exchange_confirmation: bool = True
    cross_exchange_max_divergence: float = 0.01

    @property
    def horizons(self) -> list[int]:
        return [int(v) for v in self.forecast_horizons_minutes.split(",")]


@lru_cache
def settings() -> Settings:
    return Settings()
