from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    app_env: str = "development"
    symbol: str = "XRP/USD"
    forecast_horizons_minutes: str = "15,30,60,240,1440"
    max_data_age_seconds: int = 1200
    admin_api_key: str = "change-me"
    model_name: str = "realized_volatility_random_walk"
    model_family: str = "baseline"
    database_url: str = "postgresql://xrp:xrp@localhost:5432/xrp_forecast"
    redis_url: str = "redis://localhost:6379/0"
    provider: str = "coinbase"
    alert_freshness_seconds: int = 1200

    @property
    def horizons(self) -> list[int]:
        return [int(v) for v in self.forecast_horizons_minutes.split(",")]


@lru_cache
def settings() -> Settings:
    return Settings()
