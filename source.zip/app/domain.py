from datetime import UTC, datetime
from typing import Literal

from pydantic import BaseModel, Field, field_validator

DISCLAIMER = "Forecasts are probabilistic estimates based on historical and available market data. Cryptocurrency markets are highly volatile. This tool does not provide financial, investment, trading, or legal advice, and it does not guarantee future prices or returns."


class Candle(BaseModel):
    symbol: str = "XRP/USD"
    interval_seconds: int = 60
    ts: datetime
    open: float = Field(gt=0)
    high: float = Field(gt=0)
    low: float = Field(gt=0)
    close: float = Field(gt=0)
    volume: float = Field(ge=0)
    provider: str = "demo"

    @field_validator("ts")
    @classmethod
    def utc(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("timestamp must include timezone")
        return value.astimezone(UTC)


class Quality(BaseModel):
    status: Literal["ok", "degraded", "unavailable"]
    data_freshness_seconds: float | None
    reasons: list[str] = []


class ForecastPoint(BaseModel):
    horizon_minutes: int
    target_interval_start: datetime
    p05: float
    p25: float
    p50: float
    p75: float
    p95: float
    probability_positive_return: float
    probability_above_threshold: float


class ForecastResponse(BaseModel):
    forecast_id: str
    generated_at: datetime
    reference_price: float | None
    status: Literal["ok", "degraded", "unavailable"]
    quality: Quality
    model_version: str
    model_kind: str
    uncertainty_explanation: str
    forecasts: list[ForecastPoint]
    disclaimer: str = DISCLAIMER
