from datetime import datetime, timedelta

import numpy as np

from app.domain import Candle


def candle_close_time(row: Candle) -> datetime:
    """Canonical interval-aware freshness boundary."""
    return row.ts + timedelta(seconds=row.interval_seconds)


def aggregate_15m(rows: list[Candle]) -> list[Candle]:
    buckets: dict[datetime, list[Candle]] = {}
    for row in rows:
        minute = row.ts.minute - row.ts.minute % 15
        bucket = row.ts.replace(minute=minute, second=0, microsecond=0)
        buckets.setdefault(bucket, []).append(row)
    return [
        Candle(
            symbol=rs[0].symbol,
            interval_seconds=900,
            ts=ts,
            open=rs[0].open,
            high=max(r.high for r in rs),
            low=min(r.low for r in rs),
            close=rs[-1].close,
            volume=sum(r.volume for r in rs),
            provider=rs[-1].provider,
        )
        for ts, rs in sorted(buckets.items())
    ]


def realized_volatility(rows: list[Candle], window: int = 48) -> float:
    closes = np.array([r.close for r in rows[-window:]], dtype=float)
    if len(closes) < 3:
        return 0.02
    returns = np.diff(np.log(closes))
    return max(float(np.std(returns, ddof=1)), 0.0005)


def feature_snapshot(rows: list[Candle], as_of: datetime) -> dict[str, float]:
    """Only values strictly preceding as_of; this is the leakage boundary."""
    eligible = [r for r in rows if r.ts < as_of]
    if len(eligible) < 3:
        return {}
    closes = np.array([r.close for r in eligible[-48:]])
    return {
        "return_1": float(closes[-1] / closes[-2] - 1),
        "realized_vol": realized_volatility(eligible),
        "momentum_12": float(closes[-1] / closes[max(0, len(closes) - 12)] - 1),
    }
