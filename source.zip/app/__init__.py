"""XRP probabilistic forecasting service."""
