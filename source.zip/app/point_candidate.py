"""Shadow gradient-boosted candidate for the next 15-minute close.

The candidate never changes the production distribution. It can populate the
separate possible-outcome field only after beating the naive hold-price
baseline on a chronological validation segment.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from app.domain import Candle


FEATURE_COLUMNS = [
    "return_1", "ema_gap_9", "ema_gap_21", "rsi_14", "macd", "macd_signal",
    "bb_position", "bb_width_pct",
] + [f"{name}_lag_{lag}" for lag in range(1, 7) for name in ("return", "volume")]


@dataclass(frozen=True)
class CandidateResult:
    available: bool = False
    validated: bool = False
    predicted_price: float | None = None
    samples: int = 0
    validation_samples: int = 0
    mae: float | None = None
    baseline_mae: float | None = None
    rmse: float | None = None
    baseline_rmse: float | None = None
    direction_accuracy: float | None = None
    reason: str = "candidate unavailable"

    def evidence(self) -> dict[str, float | int | bool | str]:
        values: dict[str, float | int | bool | str] = {
            "point_candidate_available": self.available,
            "point_candidate_validated": self.validated,
            "point_candidate_samples": self.samples,
            "point_candidate_validation_samples": self.validation_samples,
            "point_candidate_reason": self.reason,
        }
        for name in ("mae", "baseline_mae", "rmse", "baseline_rmse", "direction_accuracy"):
            value = getattr(self, name)
            if value is not None:
                values[f"point_candidate_{name}"] = round(value, 8)
        if self.predicted_price is not None:
            values["point_candidate_price"] = round(self.predicted_price, 8)
        return values


def _rsi(series: pd.Series, window: int = 14) -> pd.Series:
    delta = series.diff()
    gain = delta.clip(lower=0).ewm(alpha=1 / window, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1 / window, adjust=False).mean()
    rs = gain / loss.replace(0, np.nan)
    return 100 - 100 / (1 + rs)


def feature_frame(candles: list[Candle]) -> pd.DataFrame:
    """Build training and live features without dropping the latest live row."""
    frame = pd.DataFrame(
        {
            "timestamp": [row.ts for row in candles],
            "close": [row.close for row in candles],
            "volume": [row.volume for row in candles],
        }
    ).drop_duplicates("timestamp", keep="last").sort_values("timestamp")
    close = frame["close"]
    frame["return_1"] = close.pct_change()
    frame["ema_gap_9"] = close / close.ewm(span=9, adjust=False).mean() - 1
    frame["ema_gap_21"] = close / close.ewm(span=21, adjust=False).mean() - 1
    frame["rsi_14"] = _rsi(close)
    ema12, ema26 = close.ewm(span=12, adjust=False).mean(), close.ewm(span=26, adjust=False).mean()
    frame["macd"] = (ema12 - ema26) / close
    frame["macd_signal"] = (ema12 - ema26).ewm(span=9, adjust=False).mean() / close
    mean20, std20 = close.rolling(20).mean(), close.rolling(20).std()
    frame["bb_position"] = (close - mean20) / (2 * std20).replace(0, np.nan)
    frame["bb_width_pct"] = 4 * std20 / close
    volume_ratio = frame["volume"] / frame["volume"].rolling(20).median().replace(0, np.nan)
    for lag in range(1, 7):
        frame[f"return_lag_{lag}"] = frame["return_1"].shift(lag)
        frame[f"volume_lag_{lag}"] = volume_ratio.shift(lag)
    frame["target_return"] = close.shift(-1) / close - 1
    return frame


class ShadowPointCandidate:
    def __init__(self, minimum_rows: int = 180, minimum_improvement: float = 0.02) -> None:
        self.minimum_rows = minimum_rows
        self.minimum_improvement = minimum_improvement
        self._latest_timestamp = None
        self._cached = CandidateResult()

    def evaluate(self, candles: list[Candle]) -> CandidateResult:
        if candles and candles[-1].ts == self._latest_timestamp:
            return self._cached
        try:
            from sklearn.ensemble import GradientBoostingRegressor
            from sklearn.metrics import mean_absolute_error, mean_squared_error
        except ImportError:
            return CandidateResult(reason="scikit-learn is not installed")

        frame = feature_frame(candles)
        live = frame.dropna(subset=FEATURE_COLUMNS)
        training = frame.dropna(subset=FEATURE_COLUMNS + ["target_return"])
        if len(training) < self.minimum_rows or live.empty:
            return CandidateResult(
                samples=len(training), reason=f"collecting training history ({len(training)}/{self.minimum_rows})"
            )
        split = max(int(len(training) * 0.8), self.minimum_rows - 40)
        train, test = training.iloc[:split], training.iloc[split:]
        if len(test) < 30:
            return CandidateResult(samples=len(training), reason="insufficient chronological validation data")

        model = GradientBoostingRegressor(
            n_estimators=300, max_depth=3, learning_rate=0.05,
            subsample=0.8, random_state=42,
        )
        model.fit(train[FEATURE_COLUMNS], train["target_return"])
        predictions = model.predict(test[FEATURE_COLUMNS])
        actual = test["target_return"].to_numpy()
        baseline = np.zeros_like(actual)
        mae = float(mean_absolute_error(actual, predictions))
        baseline_mae = float(mean_absolute_error(actual, baseline))
        rmse = float(np.sqrt(mean_squared_error(actual, predictions)))
        baseline_rmse = float(np.sqrt(mean_squared_error(actual, baseline)))
        nonzero = actual != 0
        direction_accuracy = float(np.mean(np.sign(predictions[nonzero]) == np.sign(actual[nonzero]))) if nonzero.any() else 0.0
        validated = (
            mae <= baseline_mae * (1 - self.minimum_improvement)
            and rmse <= baseline_rmse * (1 - self.minimum_improvement)
            and direction_accuracy >= 0.52
        )

        # Refit on every labeled row only after validation. The live row remains
        # separate, fixing the common stale-row/known-target inference bug.
        predicted_price = None
        if validated:
            model.fit(training[FEATURE_COLUMNS], training["target_return"])
            predicted_return = float(model.predict(live[FEATURE_COLUMNS].iloc[[-1]])[0])
            predicted_price = float(live["close"].iloc[-1] * (1 + predicted_return))
        result = CandidateResult(
            available=True, validated=validated, predicted_price=predicted_price,
            samples=len(training), validation_samples=len(test), mae=mae,
            baseline_mae=baseline_mae, rmse=rmse, baseline_rmse=baseline_rmse,
            direction_accuracy=direction_accuracy,
            reason="validated against naive hold-price baseline" if validated else "candidate did not beat validation thresholds",
        )
        self._latest_timestamp = candles[-1].ts
        self._cached = result
        return result

