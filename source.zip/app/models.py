from datetime import UTC, datetime, timedelta
from math import erf, sqrt
from typing import ClassVar
from uuid import uuid4

from app.config import Settings
from app.domain import Candle, ForecastPoint, ForecastResponse, Quality
from app.features import realized_volatility


def normal_cdf(x: float) -> float:
    return (1 + erf(x / sqrt(2))) / 2


class RandomWalkQuantileModel:
    version = "baseline-rw-vol-v1"
    kind = "realized-volatility random walk (baseline)"
    # Standard normal quantiles, transformed on a log-price distribution.
    _z: ClassVar[dict[str, float]] = {
        "p05": -1.645,
        "p25": -0.674,
        "p50": 0.0,
        "p75": 0.674,
        "p95": 1.645,
    }

    def forecast(
        self,
        candles: list[Candle],
        cfg: Settings,
        quality: Quality,
        prediction_time: datetime | None = None,
    ) -> ForecastResponse:
        latest = candles[-1]
        sigma_15m = realized_volatility(candles)
        points: list[ForecastPoint] = []
        # Targets must be upcoming at response time. A valid last candle can be
        # several minutes old, so anchor to the later of it and the prediction time.
        # This prevents a 7:45 PM forecast remaining active after 7:45 PM starts.
        as_of = (prediction_time or latest.ts).astimezone(UTC)
        anchor = max(latest.ts, as_of)
        current_boundary = anchor.replace(
            minute=(latest.ts.minute // 15) * 15, second=0, microsecond=0
        )
        first_target = current_boundary + timedelta(minutes=15)
        for horizon in cfg.horizons:
            scale = sqrt(horizon / 15)
            sigma = sigma_15m * scale
            prices = {
                name: latest.close * __import__("math").exp(z * sigma)
                for name, z in self._z.items()
            }
            threshold = latest.close * 1.01
            prob_above = (
                1 - normal_cdf(__import__("math").log(threshold / latest.close) / sigma)
                if sigma
                else 0.0
            )
            target = first_target + timedelta(minutes=horizon - 15)
            points.append(
                ForecastPoint(
                    horizon_minutes=horizon,
                    target_interval_start=target,
                    **prices,
                    probability_positive_return=0.5,
                    probability_above_threshold=prob_above,
                )
            )
        return ForecastResponse(
            forecast_id=str(uuid4()),
            generated_at=as_of,
            reference_price=latest.close,
            status=quality.status,
            quality=quality,
            model_version=self.version,
            model_kind=self.kind,
            uncertainty_explanation="Intervals use trailing realized volatility and widen with horizon. They are baseline estimates and require walk-forward calibration before production promotion.",
            forecasts=points,
        )
