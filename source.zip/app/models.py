from datetime import UTC, datetime, timedelta
from math import erf, sqrt
from typing import ClassVar
from uuid import uuid4

from app.config import Settings
from app.domain import Candle, ForecastPoint, ForecastResponse, Quality
from app.features import realized_volatility
from app.model_monitor import MonitorSnapshot


def _direction(value: float, neutral: float) -> int:
    return 1 if value > neutral else -1 if value < -neutral else 0


def _candidate_score(closes: list[float], volumes: list[float], origin: int, kind: str) -> float:
    r1 = closes[origin] / closes[origin - 1] - 1
    r2 = closes[origin - 1] / closes[origin - 2] - 1 if origin >= 2 else 0.0
    if kind == "momentum_1":
        return r1
    if kind == "momentum_2":
        return (r1 + r2) / 2
    if kind == "mean_reversion":
        return -r1
    volume_ratio = volumes[origin] / max(volumes[origin - 1], 1e-12)
    return 0.7 * r1 + 0.3 * r2 + 0.0002 * __import__("math").tanh(volume_ratio - 1)


def select_directional_rule(candles: list[Candle], cfg: Settings) -> dict[str, float | int | str | bool]:
    """Select on past bars only; score the selected rule against a majority baseline."""
    closes = [x.close for x in candles]
    volumes = [x.volume for x in candles]
    kinds = ("momentum_1", "momentum_2", "mean_reversion", "volume_momentum")
    neutral = max(cfg.neutral_volatility_fraction * realized_volatility(candles), 0.0003)
    outcomes = [_direction(closes[i + 1] / closes[i] - 1, neutral) for i in range(2, len(closes) - 1)]
    counts = {k: outcomes.count(k) for k in (-1, 0, 1)}
    n = len(outcomes)
    baseline = max(counts.values(), default=0) / n if n else 0.0
    best = {"rule": kinds[0], "accuracy": 0.0}
    for kind in kinds:
        predictions = [_direction(_candidate_score(closes, volumes, i, kind), neutral) for i in range(2, len(closes) - 1)]
        accuracy = sum(p == y for p, y in zip(predictions, outcomes)) / n if n else 0.0
        if accuracy > float(best["accuracy"]):
            best = {"rule": kind, "accuracy": accuracy}
    raw = _candidate_score(closes, volumes, len(closes) - 1, str(best["rule"])) if len(closes) >= 3 else 0.0
    prediction = _direction(raw, neutral)
    call = n >= cfg.min_training_bars and float(best["accuracy"]) >= baseline + cfg.minimum_edge_over_baseline and prediction != 0
    return {**best, "samples": n, "baseline": baseline, "neutral_threshold": neutral, "prediction": prediction, "call": call}


def normal_cdf(x: float) -> float:
    return (1 + erf(x / sqrt(2))) / 2


class RandomWalkQuantileModel:
    version = "baseline-rw-vol-v1"
    kind = "realized-volatility random walk (baseline)"
    # Standard normal quantiles, transformed on a log-price distribution.
    _z: ClassVar[dict[str, float]] = {
        "p05": -1.645,
        "p25": -0.674,
        "p50": 0.0,
        "p75": 0.674,
        "p95": 1.645,
    }

    def forecast(
        self,
        candles: list[Candle],
        cfg: Settings,
        quality: Quality,
        prediction_time: datetime | None = None,
        monitor: MonitorSnapshot | None = None,
        context: dict[str, float | int | bool] | None = None,
    ) -> ForecastResponse:
        latest = candles[-1]
        monitor = monitor or MonitorSnapshot()
        sigma_15m = realized_volatility(candles) * monitor.interval_scale
        directional = select_directional_rule(candles, cfg)
        call = bool(directional["call"]) and not monitor.suppress_direction
        directional.update(monitor.evidence())
        if context:
            directional.update(context)
        prediction = int(directional["prediction"])
        confidence = min(max(float(directional["accuracy"]), 0.5), 0.75) if call else None
        # A deliberately small, volatility-scaled center shift; intervals remain dominant.
        center_return = prediction * sigma_15m * 0.20 if call else 0.0
        points: list[ForecastPoint] = []
        # Targets must be upcoming at response time. A valid last candle can be
        # several minutes old, so anchor to the later of it and the prediction time.
        # This prevents a 7:45 PM forecast remaining active after 7:45 PM starts.
        as_of = (prediction_time or latest.ts).astimezone(UTC)
        anchor = max(latest.ts, as_of)
        current_boundary = anchor.replace(
            minute=(anchor.minute // 15) * 15, second=0, microsecond=0
        )
        first_target = current_boundary + timedelta(minutes=15)
        for horizon in cfg.horizons:
            scale = sqrt(horizon / 15)
            sigma = sigma_15m * scale
            center = center_return * min(horizon / 15, 2)
            prices = {
                name: latest.close * __import__("math").exp(center + z * sigma)
                for name, z in self._z.items()
            }
            threshold = latest.close * 1.01
            prob_above = (
                1 - normal_cdf(__import__("math").log(threshold / latest.close) / sigma)
                if sigma
                else 0.0
            )
            target = first_target + timedelta(minutes=horizon - 15)
            points.append(
                ForecastPoint(
                    horizon_minutes=horizon,
                    target_interval_start=target,
                    **prices,
                    probability_positive_return=(normal_cdf(center / sigma) if sigma else 0.5),
                    probability_above_threshold=prob_above,
                )
            )
        return ForecastResponse(
            forecast_id=str(uuid4()),
            generated_at=as_of,
            reference_price=latest.close,
            status=quality.status,
            quality=quality,
            model_version=self.version,
            model_kind=self.kind,
            signal=("up" if prediction > 0 else "down") if call else "no_edge",
            confidence=confidence,
            evidence=directional,
            uncertainty_explanation="Intervals use trailing realized volatility and widen with horizon. Direction is emitted only when a past-only walk-forward rule has enough observations and beats the contemporaneous majority baseline; otherwise the service abstains.",
            forecasts=points,
        )
