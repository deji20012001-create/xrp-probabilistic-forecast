import json
import logging
import time
import uuid
from datetime import UTC, datetime
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request
from fastapi.responses import FileResponse
from prometheus_client import Counter, generate_latest
from starlette.responses import Response

from app.config import settings
from app.domain import DISCLAIMER, ForecastResponse
from app.ingestion.providers import CoinbaseAdapter, DemoAdapter, MarketDataAdapter
from app.model_registry import ModelRun, eligible_for_promotion
from app.services import ForecastService
from app.storage import MemoryRepository

REQUESTS = Counter("xrp_forecast_requests_total", "API requests", ["path"])
FORECAST_LATENCY = Counter("xrp_forecast_generated_total", "Generated forecasts", ["status"])
logger = logging.getLogger("xrp_forecast")
repo = MemoryRepository()


def configured_adapter() -> MarketDataAdapter:
    if settings().provider == "demo":
        return DemoAdapter()
    if settings().provider == "coinbase":
        return CoinbaseAdapter()
    raise RuntimeError("Unsupported PROVIDER; use coinbase or demo")


service = ForecastService(repo, configured_adapter(), settings())


@asynccontextmanager
async def lifespan(_: FastAPI):
    service.refresh()
    yield


app = FastAPI(title="XRP Probabilistic Forecast API", version="1.0.0", lifespan=lifespan)


@app.middleware("http")
async def structured_request_log(request: Request, call_next):
    correlation_id = request.headers.get("x-correlation-id", str(uuid.uuid4()))
    started = time.perf_counter()
    response = await call_next(request)
    response.headers["x-correlation-id"] = correlation_id
    logger.info(
        json.dumps(
            {
                "event": "http_request",
                "correlation_id": correlation_id,
                "path": request.url.path,
                "status": response.status_code,
                "latency_ms": round((time.perf_counter() - started) * 1000, 2),
            }
        )
    )
    return response


def latest() -> ForecastResponse:
    history = repo.history(1)
    if not history:
        return service.refresh()
    cached = history[-1]
    now = datetime.now(UTC)
    if not cached.forecasts or cached.forecasts[0].target_interval_start <= now:
        return service.refresh()
    return cached


def admin(x_api_key: str | None = Header(default=None)) -> None:
    if x_api_key != settings().admin_api_key:
        raise HTTPException(401, "administrative authentication required")


@app.get("/", include_in_schema=False)
def dashboard() -> FileResponse:
    return FileResponse(Path(__file__).parent / "web" / "index.html")


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "healthy"}


@app.get("/ready")
def ready() -> dict[str, str]:
    result = latest()
    if result.status == "unavailable":
        raise HTTPException(503, "forecast unavailable")
    return {"status": result.status}


@app.get("/metrics")
def metrics() -> Response:
    return Response(generate_latest(), media_type="text/plain")


@app.get("/v1/forecast/latest", response_model=ForecastResponse)
def forecast_latest() -> ForecastResponse:
    REQUESTS.labels("forecast_latest").inc()
    result = latest()
    FORECAST_LATENCY.labels(result.status).inc()
    return result


@app.post("/v1/forecast/refresh", response_model=ForecastResponse)
def forecast_refresh() -> ForecastResponse:
    """Fetch current market data and immediately regenerate a safe forecast."""
    REQUESTS.labels("forecast_refresh").inc()
    result = service.refresh()
    FORECAST_LATENCY.labels(result.status).inc()
    return result


@app.get("/v1/forecast/history", response_model=list[ForecastResponse])
def forecast_history(limit: int = Query(20, ge=1, le=200)) -> list[ForecastResponse]:
    return repo.history(limit)


@app.get("/v1/market/candles")
def market_candles(limit: int = Query(100, ge=1, le=1000)) -> list[dict]:
    return [r.model_dump(mode="json") for r in repo.get_candles(settings().symbol, 60, limit)]


@app.get("/v1/model/status")
def model_status() -> dict[str, str]:
    return {
        "model_version": service.model.version,
        "model_kind": service.model.kind,
        "promotion_policy": "Require walk-forward pinball and calibration improvement versus production baseline.",
    }


@app.post("/v1/backtests/run", dependencies=[Depends(admin)])
def run_backtest() -> dict[str, str | bool]:
    # A worker replaces this request with persisted walk-forward outputs; online inference is untouched.
    baseline = ModelRun(service.model.version, "canonical-v1", "features-v1", {}, 0.1, 0.10)
    candidate = ModelRun("candidate-untrained", "canonical-v1", "features-v1", {}, 0.1, 0.10)
    approved, reason = eligible_for_promotion(candidate, baseline)
    return {
        "status": "completed",
        "promoted": approved,
        "promotion_reason": reason,
        "note": "No unvalidated model can be promoted from this endpoint.",
    }


@app.get("/v1/disclaimer")
def disclaimer() -> dict[str, str]:
    return {"disclaimer": DISCLAIMER}
