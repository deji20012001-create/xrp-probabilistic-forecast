---
name: xrp-15min-tracker
description: Capture completed XRP/USD 15-minute OHLCV plus depth and taker-flow features without manufacturing delayed closes.
---

Run silently every 15 minutes.

1. Fetch the latest completed XRP_USD 15-minute candlestick. Never substitute a delayed ticker snapshot for a candle close.
2. Fetch 10-level order-book depth and public trades covering the completed candle.
3. Compute `ob=(bid_qty-ask_qty)/(bid_qty+ask_qty)`, `spread=best_ask-best_bid`, and `flow=(taker_buy_qty-taker_sell_qty)/(taker_buy_qty+taker_sell_qty)`.
4. Reject the update if the candle is incomplete, non-finite, non-positive, high < low, close outside [low, high], or differs by more than 20% from the prior close. Optional microstructure values may be null but must never be guessed.
5. Upsert by candle start timestamp using `{t,p,o,h,l,c,v,ob,spread,flow,fetchedAt}`. Preserve unknown existing fields and keep 10,000 records.
6. Update only the single-line history JSON with an atomic targeted replacement; do not regenerate the surrounding artifact.
7. The application performs past-only walk-forward evaluation and confidence gating. Do not persist a forced directional prediction. `No reliable edge` is valid output.
